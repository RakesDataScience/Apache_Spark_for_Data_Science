import com.databricks.spark.avro._
import org.apache.avro.Schema
import java.io.File
/**
  * Created by aribahmehreen on 21/06/17.
  */
object Csv_to_Avro {
  def main(args: Array[String]): Unit = {
    val avroSchema = new Schema.Parser().parse(new File("user.avsc"))
    val sqlSchema = SchemaConverters.toSqlType(avroSchema)
    val spark = org.apache.spark.sql.SparkSession.builder
      .master("local")
      .appName("Spark CSV Reader")
      .getOrCreate;

//    val df = sqlContext.read
//     .format("com.databricks.spark.csv")
//      .option("delimiter", "|")
//      .option("header", "false")
//      .option("inferSchema", "true")
//      .schema(sqlSchema)
//      .load(file)
//      .write
//      .avro("data/")

    val df = spark.read
      .format("com.databricks.spark.csv")
      .option("header", "true") //reading the headers
      .option("mode", "DROPMALFORMED")
      .load("data/home_data.csv"); //

    df.write.format("com.databricks.spark.avro").save("data/home_data_avro/")

  }
}
