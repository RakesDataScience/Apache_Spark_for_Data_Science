
/**
  * Created by aribahmehreen on 21/06/17.
  */
object SparkAvro {
  def main(args: Array[String]): Unit = {

    val spark = org.apache.spark.sql.SparkSession.builder
      .master("local")
      .appName("Spark CSV Reader")
      .getOrCreate;

    val df = spark.read
      .format("com.databricks.spark.csv")
      .option("header", "true") //reading the headers
      .option("mode", "DROPMALFORMED")
      .load("data/home_data.csv"); //.csv("csv/file/path") //spark 2.0 api

    df.show()
    df.write.format("com.databricks.spark.avro").save("data/home_data_avro/")

  }


}
